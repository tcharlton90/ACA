int branchPredict(int reg);

int getPred (int address);